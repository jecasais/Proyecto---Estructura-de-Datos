package proyectoestrucdatos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.swing_viewer.SwingViewer;
import org.graphstream.ui.swing_viewer.ViewPanel;
import org.graphstream.ui.view.Viewer;

public class PanelGrafo extends JPanel {

    private static final String[] PALETA = {
        "#D32F2F", "#1976D2", "#F57C00", "#388E3C", "#7B1FA2", "#00897B", "#C2185B", "#5D4037"
    };
    private static final String COLOR_RUTA = "#FFD600";
    private static final String COLOR_ALERTA = "#212121";
    private static final String HOJA_ESTILO =
        "graph { fill-color: #FAFAFA; padding: 40px; }"
        + "node { size: 16px; text-size: 11px; text-alignment: above; text-style: bold; "
        + "stroke-mode: plain; stroke-color: #37474F; stroke-width: 1px; fill-color: #90A4AE; }"
        + "edge { size: 2px; fill-color: #90A4AE; text-size: 9px; text-color: #78909C; }";

    private final Graph grafoVisual;
    private final Viewer visor;
    private final JPanel leyenda;
    private Grafo grafoActual;
    private ListaEnlazada<Estacion> rutaResaltada;
    private ListaEnlazada<ListaEnlazada<Estacion>> subredesResaltadas;

    public PanelGrafo() {
        super(new BorderLayout());
        System.setProperty("org.graphstream.ui", "swing");

        grafoVisual = new SingleGraph("UrbanRoute");
        grafoVisual.setAttribute("ui.stylesheet", HOJA_ESTILO);
        grafoVisual.setAttribute("ui.quality");
        grafoVisual.setAttribute("ui.antialias");

        // GRAPH_IN_ANOTHER_THREAD evita que el lienzo Swing se quede bloqueado en blanco
        visor = new SwingViewer(grafoVisual, Viewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
        visor.enableAutoLayout();

        ViewPanel vista = (ViewPanel) visor.addDefaultView(false);
        add((Component) vista, BorderLayout.CENTER);

        leyenda = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4));
        leyenda.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(0xCFD8DC)));
        add(leyenda, BorderLayout.SOUTH);
    }

    public void actualizar(Grafo grafo) {
        this.grafoActual = grafo;
        this.rutaResaltada = null;
        this.subredesResaltadas = null;

        sincronizarNodos(grafo);
        sincronizarAristas(grafo);
        aplicarColoresPorLinea(grafo);
        actualizarLeyenda(grafo);

        visor.enableAutoLayout();
        revalidate();
        repaint();
    }

    public void resaltarRuta(ListaEnlazada<Estacion> ruta) {
        this.rutaResaltada = ruta;
        if (grafoActual == null) return;

        aplicarColoresPorLinea(grafoActual);

        if (ruta != null && ruta.getTamano() > 0) {
            Nodo<Estacion> actual = ruta.getCabeza();
            while (actual != null) {
                Node n = grafoVisual.getNode(actual.getDato().getId());
                if (n != null) {
                    n.setAttribute("ui.style", "fill-color: " + COLOR_RUTA + "; size: 22px; stroke-width: 2px;");
                }
                if (actual.getSiguiente() != null) {
                    String idA = actual.getDato().getId();
                    String idB = actual.getSiguiente().getDato().getId();
                    Edge e = buscarAristaVisual(idA, idB);
                    if (e != null) {
                        e.setAttribute("ui.style", "fill-color: " + COLOR_RUTA + "; size: 4px;");
                    }
                }
                actual = actual.getSiguiente();
            }
        }
        repaint();
    }

    public void resaltarSubredes(ListaEnlazada<ListaEnlazada<Estacion>> subredes) {
        this.subredesResaltadas = subredes;
        if (grafoActual == null || subredes == null) return;

        int colorIdx = 0;
        Nodo<ListaEnlazada<Estacion>> subNodo = subredes.getCabeza();
        while (subNodo != null) {
            String color = PALETA[colorIdx % PALETA.length];
            Nodo<Estacion> estNodo = subNodo.getDato().getCabeza();
            while (estNodo != null) {
                Node n = grafoVisual.getNode(estNodo.getDato().getId());
                if (n != null) {
                    n.setAttribute("ui.style", "fill-color: " + color + "; size: 18px;");
                }
                estNodo = estNodo.getSiguiente();
            }
            colorIdx++;
            subNodo = subNodo.getSiguiente();
        }
        repaint();
    }

    private void sincronizarNodos(Grafo grafo) {
        if (grafo == null) return;

        for (int i = grafoVisual.getNodeCount() - 1; i >= 0; i--) {
            String id = grafoVisual.getNode(i).getId();
            if (grafo.buscarVertice(id) == null) {
                grafoVisual.removeNode(id);
            }
        }

        Nodo<Vertice> aux = grafo.getVertices().getCabeza();
        while (aux != null) {
            Estacion est = aux.getDato().getEstacion();
            Node n = grafoVisual.getNode(est.getId());
            if (n == null) {
                n = grafoVisual.addNode(est.getId());
                // Posición inicial aleatoria para evitar que todos los nodos nazcan en (0,0)
                n.setAttribute("xyz", Math.random() * 100, Math.random() * 100, 0);
            }
            n.setAttribute("ui.label", est.getNombre());
            aux = aux.getSiguiente();
        }
    }

    private void sincronizarAristas(Grafo grafo) {
        if (grafo == null) return;

        for (int i = grafoVisual.getEdgeCount() - 1; i >= 0; i--) {
            Edge e = grafoVisual.getEdge(i);
            String a = e.getNode0().getId();
            String b = e.getNode1().getId();
            Vertice va = grafo.buscarVertice(a);
            if (va == null || va.buscarArista(b) == null) {
                grafoVisual.removeEdge(e.getId());
            }
        }

        Nodo<Vertice> auxV = grafo.getVertices().getCabeza();
        while (auxV != null) {
            String idA = auxV.getDato().getEstacion().getId();
            Nodo<Arista> auxA = auxV.getDato().getAdyacentes().getCabeza();
            while (auxA != null) {
                String idB = auxA.getDato().getDestino().getId();
                if (buscarAristaVisual(idA, idB) == null) {
                    String edgeId = idA + "-" + idB;
                    Edge e = grafoVisual.addEdge(edgeId, idA, idB, false);
                    e.setAttribute("ui.label", auxA.getDato().getTiempoMinutos() + "m");
                }
                auxA = auxA.getSiguiente();
            }
            auxV = auxV.getSiguiente();
        }
    }

    private Edge buscarAristaVisual(String idA, String idB) {
        Edge e = grafoVisual.getEdge(idA + "-" + idB);
        if (e == null) {
            e = grafoVisual.getEdge(idB + "-" + idA);
        }
        return e;
    }

    private void aplicarColoresPorLinea(Grafo grafo) {
        for (int i = 0; i < grafoVisual.getEdgeCount(); i++) {
            grafoVisual.getEdge(i).setAttribute("ui.style", "fill-color: #90A4AE; size: 2px;");
        }

        ListaEnlazada<String> lineas = new ListaEnlazada<>();
        Nodo<Vertice> aux = grafo.getVertices().getCabeza();
        while (aux != null) {
            Estacion est = aux.getDato().getEstacion();
            int idx = obtenerIndiceLinea(lineas, est.getLinea());
            String color = PALETA[idx % PALETA.length];
            Node n = grafoVisual.getNode(est.getId());
            if (n != null) {
                n.setAttribute("ui.style", "fill-color: " + color + "; size: 16px;");
            }
            aux = aux.getSiguiente();
        }
    }

    private int obtenerIndiceLinea(ListaEnlazada<String> lineas, String linea) {
        int index = 0;
        Nodo<String> aux = lineas.getCabeza();
        while (aux != null) {
            if (aux.getDato().equalsIgnoreCase(linea)) {
                return index;
            }
            index++;
            aux = aux.getSiguiente();
        }
        lineas.agregar(linea);
        return index;
    }
    
    public void limpiarResaltado() {
        this.rutaResaltada = null;
        this.subredesResaltadas = null;
        if (grafoActual != null) {
            aplicarColoresPorLinea(grafoActual);
        }
        repaint();
    }

    private void actualizarLeyenda(Grafo grafo) {
        leyenda.removeAll();
        if (grafo == null) return;

        ListaEnlazada<String> lineas = new ListaEnlazada<>();
        Nodo<Vertice> aux = grafo.getVertices().getCabeza();
        while (aux != null) {
            String linea = aux.getDato().getEstacion().getLinea();
            int idx = obtenerIndiceLinea(lineas, linea);
            aux = aux.getSiguiente();
        }

        int idx = 0;
        Nodo<String> lNodo = lineas.getCabeza();
        while (lNodo != null) {
            JLabel lbl = new JLabel("● " + lNodo.getDato());
            lbl.setForeground(Color.decode(PALETA[idx % PALETA.length]));
            leyenda.add(lbl);
            idx++;
            lNodo = lNodo.getSiguiente();
        }
        leyenda.revalidate();
        leyenda.repaint();
    }
    
    public void cerrar() {
        if (visor != null) {
            visor.disableAutoLayout();
            visor.close();
        }
    }
}