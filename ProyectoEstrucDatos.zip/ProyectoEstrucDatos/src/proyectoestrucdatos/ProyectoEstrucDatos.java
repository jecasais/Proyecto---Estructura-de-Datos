package proyectoestrucdatos;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Clase principal que inicia el Sistema de Gestión de Rutas Urbanas.
 */

public class ProyectoEstrucDatos {

    public static void main(String[] args) {
        System.setProperty("org.graphstream.ui", "swing");

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }

        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}