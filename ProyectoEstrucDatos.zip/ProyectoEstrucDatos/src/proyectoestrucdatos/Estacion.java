package proyectoestrucdatos;

public class Estacion {
    private String id;
    private String nombre;
    private String linea;
    private String zona;
    private int capacidad;

    public Estacion(String id, String nombre, String linea, String zona, int capacidad) {
        this.id = id;
        this.nombre = nombre;
        this.linea = linea;
        this.zona = zona;
        this.capacidad = capacidad;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLinea() {
        return linea;
    }

    public void setLinea(String linea) {
        this.linea = linea;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }


    public String toString() {
        return id + " - " + nombre + " (" + linea + ")";
    }
    
   

    public int getCapacidadPasajeros() {
        return capacidad;
    }

    
    public void setCapacidadPasajeros(int capacidad) {
        this.capacidad = capacidad;
    }
}